from django.shortcuts import render


# def blog_list(request):
#     return render(request, "blog_list.html")


# def blog_test(request):
#     return render(request, "blog_test.html")


# def blog_detail(request, pk):
#     return render(request, "blog_detail.html")
