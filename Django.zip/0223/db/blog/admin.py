from django.contrib import admin
from .models import Post

admin.site.register(Post)  # admin page 커스터마이징은 뒤에서 배웁니다.
